// Application Data from the provided JSON
const AppData = {
  detected_articles: [
    {
      id: 1,
      title: "OpenAI Announces GPT-5 with Advanced Reasoning Capabilities",
      url: "https://techcrunch.com/2025/01/08/openai-gpt5-launch",
      source: "TechCrunch",
      category: "AI/Technology",
      excerpt: "OpenAI unveiled GPT-5 today, featuring breakthrough reasoning capabilities and multimodal understanding that significantly surpasses previous models.",
      author: "Sarah Chen",
      published_date: "2025-01-08T14:00:00Z",
      word_count: 450,
      selected: false
    },
    {
      id: 2,
      title: "Tesla's Revolutionary Battery Technology Achieves 1000-Mile Range",
      url: "https://techcrunch.com/2025/01/08/tesla-battery-breakthrough",
      source: "TechCrunch", 
      category: "Automotive",
      excerpt: "Tesla announces breakthrough in solid-state battery technology that could revolutionize electric vehicle adoption with unprecedented range capabilities.",
      author: "Michael Torres",
      published_date: "2025-01-08T13:30:00Z",
      word_count: 380,
      selected: false
    },
    {
      id: 3,
      title: "Global Climate Summit Reaches Historic Carbon Reduction Agreement",
      url: "https://bbc.com/news/climate-summit-agreement",
      source: "BBC News",
      category: "Environment",
      excerpt: "World leaders agree on ambitious new targets for carbon reduction at the global climate summit, marking a turning point in environmental policy.",
      author: "Emma Thompson", 
      published_date: "2025-01-08T12:00:00Z",
      word_count: 520,
      selected: false
    },
    {
      id: 4,
      title: "Breakthrough in Quantum Computing Achieved by IBM Research",
      url: "https://techcrunch.com/2025/01/08/ibm-quantum-breakthrough",
      source: "TechCrunch",
      category: "Technology",
      excerpt: "IBM researchers demonstrate practical quantum advantage in solving complex optimization problems, bringing quantum computing closer to mainstream adoption.",
      author: "Dr. James Wilson",
      published_date: "2025-01-08T11:30:00Z", 
      word_count: 420,
      selected: false
    },
    {
      id: 5,
      title: "SpaceX Successfully Tests New Interplanetary Propulsion System",
      url: "https://spacenews.com/spacex-propulsion-test",
      source: "SpaceNews",
      category: "Space",
      excerpt: "SpaceX conducts successful test of revolutionary propulsion system designed for Mars missions, marking significant progress in interplanetary travel technology.",
      author: "Lisa Rodriguez",
      published_date: "2025-01-08T10:45:00Z",
      word_count: 395,
      selected: false
    }
  ],
  finished_articles: [
    {
      id: 1,
      original_id: 2,
      title: "Revolutionary Electric Vehicle Battery Technology Promises Game-Changing Range",
      content: "Electric vehicle technology has taken a massive leap forward with Tesla's announcement of their groundbreaking solid-state battery system. This new technology promises to deliver over 1,000 miles of range on a single charge, effectively eliminating range anxiety that has long been a barrier to EV adoption.\n\nThe innovation centers around advanced lithium-metal chemistry combined with proprietary solid electrolytes. This combination delivers significantly higher energy density while maintaining superior safety standards compared to traditional lithium-ion batteries. Industry experts believe this breakthrough could accelerate the global transition to sustainable transportation.\n\nWhat makes this development particularly exciting is its potential impact on the automotive industry as a whole. With such extended range capabilities, electric vehicles become viable for long-distance travel without the need for frequent charging stops. This addresses one of the primary concerns consumers have had about making the switch from gasoline-powered vehicles.\n\nThe technology also promises faster charging times and improved battery longevity, making electric vehicles more practical and cost-effective for everyday use. Tesla expects to begin implementation of this technology in their vehicle lineup within the next two years, with other manufacturers likely to follow suit.",
      original_content: "Tesla announces breakthrough in solid-state battery technology that could revolutionize electric vehicle adoption with unprecedented range capabilities.",
      original_word_count: 380,
      final_word_count: 420,
      processing_pipeline: {
        ai_generated: {
          status: "completed",
          timestamp: "2025-01-08T15:00:00Z",
          method: "OpenAI GPT-4"
        },
        ai_detection: {
          status: "completed", 
          timestamp: "2025-01-08T15:02:00Z",
          score: 0.15,
          confidence: "low",
          detector: "Multiple (GPTZero, Originality.ai)"
        },
        humanization: {
          status: "completed",
          timestamp: "2025-01-08T15:05:00Z",
          method: "Advanced rewriting",
          improvement_score: 0.85
        },
        plagiarism_check: {
          status: "completed",
          timestamp: "2025-01-08T15:07:00Z", 
          similarity_score: 0.08,
          sources_checked: 15000000,
          result: "original"
        }
      },
      quality_scores: {
        readability: 8.7,
        seo_score: 92,
        human_likeness: 94,
        originality: 98
      },
      selected: false,
      created_at: "2025-01-08T15:07:00Z"
    },
    {
      id: 2,
      original_id: 3,
      title: "World Leaders Unite for Ambitious Climate Action at Historic Summit",
      content: "A landmark moment in environmental policy unfolded as world leaders reached a comprehensive agreement on carbon reduction targets at the recent global climate summit. This historic accord represents the most ambitious collective commitment to combating climate change in decades.\n\nThe agreement establishes aggressive timelines for nations to achieve carbon neutrality, with developed countries committing to net-zero emissions by 2040 and developing nations by 2050. What sets this agreement apart from previous climate accords is the inclusion of specific, measurable milestones and accountability mechanisms.\n\nKey provisions include substantial investments in renewable energy infrastructure, with participating nations pledging to triple their clean energy capacity within the next decade. The accord also addresses critical issues like deforestation, with binding commitments to halt forest destruction and restore degraded ecosystems.\n\nFinancial support for developing nations features prominently in the agreement, with developed countries committing $500 billion annually to help emerging economies transition to clean energy systems. This funding mechanism addresses one of the longstanding barriers to global climate action.\n\nEnvironmental advocates are cautiously optimistic about the agreement's potential impact. Unlike previous climate deals that lacked enforcement mechanisms, this accord includes regular progress reviews and potential consequences for non-compliance. The success of this initiative will largely depend on whether nations follow through on their ambitious commitments.",
      original_content: "World leaders agree on ambitious new targets for carbon reduction at the global climate summit, marking a turning point in environmental policy.",
      original_word_count: 520,
      final_word_count: 485,
      processing_pipeline: {
        ai_generated: {
          status: "completed",
          timestamp: "2025-01-08T15:10:00Z", 
          method: "OpenAI GPT-4"
        },
        ai_detection: {
          status: "completed",
          timestamp: "2025-01-08T15:12:00Z",
          score: 0.12,
          confidence: "low", 
          detector: "Multiple (GPTZero, Originality.ai)"
        },
        humanization: {
          status: "completed",
          timestamp: "2025-01-08T15:15:00Z",
          method: "Advanced rewriting",
          improvement_score: 0.88
        },
        plagiarism_check: {
          status: "completed", 
          timestamp: "2025-01-08T15:17:00Z",
          similarity_score: 0.06,
          sources_checked: 15000000,
          result: "original"
        }
      },
      quality_scores: {
        readability: 9.1,
        seo_score: 89,
        human_likeness: 96, 
        originality: 99
      },
      selected: false,
      created_at: "2025-01-08T15:17:00Z"
    }
  ],
  processing_stats: {
    total_articles_processed: 2,
    average_processing_time: "7.5 minutes",
    success_rate: "100%",
    quality_improvement: "92%"
  }
};

// Application State
let currentSection = 'url-input';
let showComparison = false;
let processingInProgress = false;

// DOM Elements
const navButtons = document.querySelectorAll('.nav-btn');
const sections = document.querySelectorAll('.section');
const themeToggle = document.getElementById('themeToggle');

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
  initializeApp();
  setupEventListeners();
  renderDetectedArticles();
  renderFinishedArticles();
  updateProcessingStats();
});

function initializeApp() {
  // Set initial theme
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-color-scheme', savedTheme);
  updateThemeIcon(savedTheme);
  
  // Show initial section
  switchSection('url-input');
}

function updateThemeIcon(theme) {
  if (themeToggle) {
    themeToggle.textContent = theme === 'dark' ? '☀️' : '🌙';
  }
}

function setupEventListeners() {
  // Navigation
  navButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const section = btn.dataset.section;
      switchSection(section);
    });
  });

  // Theme toggle
  themeToggle?.addEventListener('click', toggleTheme);

  // URL Input Section
  document.getElementById('discoverBtn').addEventListener('click', discoverArticles);
  document.getElementById('websiteUrl').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') discoverArticles();
  });

  // Filter controls
  document.getElementById('searchFilter').addEventListener('input', filterArticles);
  document.getElementById('sourceFilter').addEventListener('change', filterArticles);
  document.getElementById('categoryFilter').addEventListener('change', filterArticles);

  // Selection controls
  document.getElementById('selectAllBtn').addEventListener('click', selectAllArticles);
  document.getElementById('clearAllBtn').addEventListener('click', clearAllArticles);
  document.getElementById('processSelectedBtn').addEventListener('click', processSelectedArticles);

  // Finished Articles Section
  document.getElementById('exportSelectedBtn').addEventListener('click', exportSelectedArticles);
  document.getElementById('batchExportBtn').addEventListener('click', batchExportAll);
  document.getElementById('toggleComparisonBtn').addEventListener('click', toggleBeforeAfterComparison);

  // Modal controls
  document.getElementById('pipelineModalClose').addEventListener('click', closePipelineModal);
  document.getElementById('previewModalClose').addEventListener('click', closePreviewModal);
  document.getElementById('previewCloseBtn').addEventListener('click', closePreviewModal);
  document.getElementById('previewSelectBtn').addEventListener('click', selectPreviewedArticle);
}

function switchSection(sectionName) {
  // Update navigation
  navButtons.forEach(btn => {
    btn.classList.remove('active');
    if (btn.dataset.section === sectionName) {
      btn.classList.add('active');
    }
  });

  // Update sections
  sections.forEach(section => {
    section.classList.remove('active');
    if (section.id === sectionName) {
      section.classList.add('active');
    }
  });

  currentSection = sectionName;
}

function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-color-scheme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  
  document.documentElement.setAttribute('data-color-scheme', newTheme);
  localStorage.setItem('theme', newTheme);
  updateThemeIcon(newTheme);
}

// Article Discovery Functions
function discoverArticles() {
  const urlInput = document.getElementById('websiteUrl');
  const url = urlInput.value.trim();
  
  if (!url) {
    alert('Please enter a website URL');
    return;
  }

  showProcessingStatus();
  simulateDiscovery();
}

function showProcessingStatus() {
  const processingStatus = document.getElementById('processingStatus');
  const discoverySection = document.getElementById('discoverySection');
  
  processingStatus.classList.remove('hidden');
  discoverySection.style.display = 'none';
}

function simulateDiscovery() {
  const progressFill = document.getElementById('progressFill');
  const statusTitle = document.getElementById('statusTitle');
  const statusMessage = document.getElementById('statusMessage');
  
  let progress = 0;
  const progressSteps = [
    { progress: 25, title: "Analyzing Website Structure...", message: "Detecting page layout and article containers" },
    { progress: 50, title: "Identifying Articles...", message: "Finding article links and content selectors" },
    { progress: 75, title: "Extracting Content...", message: "Scraping article titles, excerpts, and metadata" },
    { progress: 100, title: "Processing Complete!", message: "Successfully discovered articles" }
  ];
  
  let currentStep = 0;
  
  const progressInterval = setInterval(() => {
    if (currentStep < progressSteps.length) {
      const step = progressSteps[currentStep];
      progress = step.progress;
      statusTitle.textContent = step.title;
      statusMessage.textContent = step.message;
      progressFill.style.width = progress + '%';
      currentStep++;
      
      if (progress === 100) {
        clearInterval(progressInterval);
        setTimeout(showDiscoveryResults, 1000);
      }
    }
  }, 1000);
}

function showDiscoveryResults() {
  const processingStatus = document.getElementById('processingStatus');
  const discoverySection = document.getElementById('discoverySection');
  
  processingStatus.classList.add('hidden');
  discoverySection.style.display = 'block';
  
  renderDetectedArticles();
  updateProcessSelectedButton();
}

function renderDetectedArticles() {
  const articlesGrid = document.getElementById('articlesGrid');
  const filteredArticles = getFilteredArticles();
  
  articlesGrid.innerHTML = '';
  
  filteredArticles.forEach(article => {
    const articleCard = createArticleCard(article);
    articlesGrid.appendChild(articleCard);
  });
}

function createArticleCard(article) {
  const card = document.createElement('div');
  card.className = `article-card ${article.selected ? 'selected' : ''}`;
  card.dataset.articleId = article.id;
  
  card.innerHTML = `
    <input type="checkbox" class="article-checkbox" ${article.selected ? 'checked' : ''}>
    <div class="article-content">
      <h4 class="article-title">${article.title}</h4>
      <div class="article-excerpt">${article.excerpt}</div>
      <div class="article-meta">
        <span class="article-source">${article.source} • ${article.category}</span>
        <span>${formatDate(article.published_date)} • ${article.word_count} words</span>
      </div>
      <div class="article-actions">
        <button class="btn btn--outline" onclick="previewArticle(${article.id})">Preview</button>
        <button class="btn btn--primary" onclick="selectArticle(${article.id})">
          ${article.selected ? 'Selected' : 'Select'}
        </button>
      </div>
    </div>
  `;
  
  // Add event listener for checkbox
  const checkbox = card.querySelector('.article-checkbox');
  checkbox.addEventListener('change', () => toggleArticleSelection(article.id));
  
  return card;
}

function getFilteredArticles() {
  const searchTerm = document.getElementById('searchFilter').value.toLowerCase();
  const sourceFilter = document.getElementById('sourceFilter').value;
  const categoryFilter = document.getElementById('categoryFilter').value;
  
  return AppData.detected_articles.filter(article => {
    const matchesSearch = !searchTerm || 
      article.title.toLowerCase().includes(searchTerm) ||
      article.excerpt.toLowerCase().includes(searchTerm) ||
      article.author.toLowerCase().includes(searchTerm);
    
    const matchesSource = !sourceFilter || article.source === sourceFilter;
    const matchesCategory = !categoryFilter || article.category === categoryFilter;
    
    return matchesSearch && matchesSource && matchesCategory;
  });
}

function filterArticles() {
  renderDetectedArticles();
}

function toggleArticleSelection(articleId) {
  const article = AppData.detected_articles.find(a => a.id === articleId);
  if (article) {
    article.selected = !article.selected;
    renderDetectedArticles();
    updateProcessSelectedButton();
  }
}

function selectArticle(articleId) {
  toggleArticleSelection(articleId);
}

function selectAllArticles() {
  const filteredArticles = getFilteredArticles();
  filteredArticles.forEach(article => {
    article.selected = true;
  });
  renderDetectedArticles();
  updateProcessSelectedButton();
}

function clearAllArticles() {
  AppData.detected_articles.forEach(article => {
    article.selected = false;
  });
  renderDetectedArticles();
  updateProcessSelectedButton();
}

function updateProcessSelectedButton() {
  const processBtn = document.getElementById('processSelectedBtn');
  const selectedCount = AppData.detected_articles.filter(a => a.selected).length;
  
  processBtn.disabled = selectedCount === 0;
  processBtn.textContent = selectedCount > 0 ? 
    `Process Selected Articles (${selectedCount})` : 
    'Process Selected Articles';
}

function processSelectedArticles() {
  const selectedArticles = AppData.detected_articles.filter(a => a.selected);
  
  if (selectedArticles.length === 0) {
    alert('Please select at least one article to process');
    return;
  }
  
  if (processingInProgress) {
    alert('Processing is already in progress');
    return;
  }
  
  showPipelineModal();
  simulateProcessingPipeline(selectedArticles);
}

// Processing Pipeline Functions
function showPipelineModal() {
  const modal = document.getElementById('pipelineModal');
  modal.classList.remove('hidden');
  processingInProgress = true;
  
  // Reset all steps
  const steps = document.querySelectorAll('.pipeline-step');
  steps.forEach(step => {
    step.classList.remove('active', 'completed');
    const status = step.querySelector('.step-status');
    status.textContent = 'Pending';
  });
  
  // Reset progress
  document.getElementById('pipelineProgress').style.width = '0%';
  document.getElementById('pipelineProgressText').textContent = 'Initializing pipeline...';
}

function simulateProcessingPipeline(articles) {
  const steps = [
    { id: 'step-ai-generation', name: 'AI Generation', duration: 2000 },
    { id: 'step-ai-detection', name: 'AI Detection Check', duration: 1500 },
    { id: 'step-humanization', name: 'Humanization', duration: 2500 },
    { id: 'step-plagiarism', name: 'Plagiarism Check', duration: 2000 }
  ];
  
  let currentStep = 0;
  
  function processStep() {
    if (currentStep >= steps.length) {
      completePipeline(articles);
      return;
    }
    
    const step = steps[currentStep];
    const stepElement = document.getElementById(step.id);
    const statusElement = stepElement.querySelector('.step-status');
    
    // Mark step as active
    stepElement.classList.add('active');
    statusElement.textContent = 'In Progress';
    
    // Update progress
    const progress = ((currentStep + 1) / steps.length) * 100;
    document.getElementById('pipelineProgress').style.width = progress + '%';
    document.getElementById('pipelineProgressText').textContent = 
      `Step ${currentStep + 1} of ${steps.length}: ${step.name}...`;
    
    setTimeout(() => {
      // Mark step as completed
      stepElement.classList.remove('active');
      stepElement.classList.add('completed');
      statusElement.textContent = 'Completed';
      
      currentStep++;
      processStep();
    }, step.duration);
  }
  
  processStep();
}

function completePipeline(selectedArticles) {
  document.getElementById('pipelineProgressText').textContent = 'Pipeline completed successfully!';
  
  setTimeout(() => {
    closePipelineModal();
    
    // Simulate creating new finished articles from selected articles
    selectedArticles.forEach((article, index) => {
      if (!AppData.finished_articles.find(fa => fa.original_id === article.id)) {
        const newFinishedArticle = {
          id: AppData.finished_articles.length + index + 1,
          original_id: article.id,
          title: `Processed: ${article.title}`,
          content: `${article.excerpt} This article has been enhanced through our AI processing pipeline with improved readability, SEO optimization, and human-like writing style. The content has been expanded and refined while maintaining the original message and intent.`,
          original_content: article.excerpt,
          original_word_count: article.word_count,
          final_word_count: article.word_count + 50,
          processing_pipeline: {
            ai_generated: { status: "completed", timestamp: new Date().toISOString() },
            ai_detection: { status: "completed", timestamp: new Date().toISOString() },
            humanization: { status: "completed", timestamp: new Date().toISOString() },
            plagiarism_check: { status: "completed", timestamp: new Date().toISOString() }
          },
          quality_scores: {
            readability: Math.floor(Math.random() * 3) + 8,
            seo_score: Math.floor(Math.random() * 10) + 85,
            human_likeness: Math.floor(Math.random() * 5) + 90,
            originality: Math.floor(Math.random() * 5) + 95
          },
          selected: false,
          created_at: new Date().toISOString()
        };
        AppData.finished_articles.push(newFinishedArticle);
      }
    });
    
    // Update stats
    AppData.processing_stats.total_articles_processed = AppData.finished_articles.length;
    updateProcessingStats();
    
    // Clear selections
    clearAllArticles();
    
    // Re-render finished articles
    renderFinishedArticles();
    
    // Switch to finished articles section
    switchSection('finished-articles');
    
    processingInProgress = false;
    
    alert(`Successfully processed ${selectedArticles.length} articles! Check the Finished Articles section.`);
  }, 1500);
}

function closePipelineModal() {
  document.getElementById('pipelineModal').classList.add('hidden');
}

// Preview Functions
function previewArticle(articleId) {
  const article = AppData.detected_articles.find(a => a.id === articleId);
  if (!article) return;
  
  const modal = document.getElementById('articlePreviewModal');
  const title = document.getElementById('previewTitle');
  const content = document.getElementById('previewContent');
  
  title.textContent = article.title;
  content.innerHTML = `
    <div class="article-meta" style="margin-bottom: 16px; font-size: 14px; color: var(--color-text-secondary);">
      <strong>Source:</strong> ${article.source} • 
      <strong>Category:</strong> ${article.category} • 
      <strong>Author:</strong> ${article.author}
    </div>
    <div style="margin-bottom: 16px; line-height: 1.5;">
      ${article.excerpt}
    </div>
    <div style="font-size: 12px; color: var(--color-text-secondary);">
      <strong>Published:</strong> ${formatDate(article.published_date)} • 
      <strong>Word Count:</strong> ${article.word_count} words
    </div>
  `;
  
  modal.classList.remove('hidden');
  modal.dataset.articleId = articleId;
}

function closePreviewModal() {
  document.getElementById('articlePreviewModal').classList.add('hidden');
}

function selectPreviewedArticle() {
  const modal = document.getElementById('articlePreviewModal');
  const articleId = parseInt(modal.dataset.articleId);
  
  toggleArticleSelection(articleId);
  closePreviewModal();
}

// Finished Articles Functions
function renderFinishedArticles() {
  const articlesList = document.getElementById('finishedArticlesList');
  articlesList.innerHTML = '';
  
  AppData.finished_articles.forEach(article => {
    const articleCard = createFinishedArticleCard(article);
    articlesList.appendChild(articleCard);
  });
  
  if (AppData.finished_articles.length === 0) {
    articlesList.innerHTML = `
      <div style="text-align: center; padding: 60px 20px; color: var(--color-text-secondary);">
        <h4>No finished articles yet</h4>
        <p>Process some articles from the Article Selection section to see them here.</p>
        <button class="btn btn--primary" onclick="switchSection('url-input')">
          Go to Article Selection
        </button>
      </div>
    `;
  }
}

function createFinishedArticleCard(article) {
  const card = document.createElement('div');
  card.className = `finished-article-card ${article.selected ? 'selected' : ''}`;
  card.dataset.articleId = article.id;
  
  const processingBadges = Object.entries(article.processing_pipeline)
    .filter(([key, value]) => value.status === 'completed')
    .map(([key, value]) => {
      const badgeNames = {
        ai_generated: 'AI Generated',
        ai_detection: 'AI Detection',
        humanization: 'Humanized',
        plagiarism_check: 'Plagiarism Free'
      };
      return `<span class="processing-badge completed">✓ ${badgeNames[key]}</span>`;
    }).join('');
  
  const comparisonSection = showComparison ? `
    <div class="before-after-comparison">
      <div class="comparison-section">
        <h5>Original Content</h5>
        <div class="comparison-content">${article.original_content}</div>
      </div>
      <div class="comparison-section">
        <h5>Processed Content</h5>
        <div class="comparison-content">${article.content.substring(0, 200)}...</div>
      </div>
    </div>
  ` : `
    <div class="article-content-preview">
      ${article.content.substring(0, 300)}...
    </div>
  `;
  
  card.innerHTML = `
    <div class="finished-article-header">
      <h3 class="finished-article-title">${article.title}</h3>
      <input type="checkbox" class="finished-article-checkbox" 
             ${article.selected ? 'checked' : ''}>
    </div>
    
    <div class="processing-badges">
      ${processingBadges}
    </div>
    
    <div class="quality-scores">
      <div class="quality-score">
        <span class="score-value">${article.quality_scores.readability}</span>
        <span class="score-label">Readability</span>
      </div>
      <div class="quality-score">
        <span class="score-value">${article.quality_scores.seo_score}</span>
        <span class="score-label">SEO Score</span>
      </div>
      <div class="quality-score">
        <span class="score-value">${article.quality_scores.human_likeness}</span>
        <span class="score-label">Human-likeness</span>
      </div>
      <div class="quality-score">
        <span class="score-value">${article.quality_scores.originality}</span>
        <span class="score-label">Originality</span>
      </div>
    </div>
    
    ${comparisonSection}
    
    <div class="finished-article-actions">
      <button class="btn btn--outline" onclick="exportSingleArticle(${article.id}, 'txt')">Export TXT</button>
      <button class="btn btn--outline" onclick="exportSingleArticle(${article.id}, 'html')">Export HTML</button>
      <button class="btn btn--outline" onclick="exportSingleArticle(${article.id}, 'json')">Export JSON</button>
    </div>
  `;
  
  // Add event listener for checkbox
  const checkbox = card.querySelector('.finished-article-checkbox');
  checkbox.addEventListener('change', () => toggleFinishedArticleSelection(article.id));
  
  return card;
}

function toggleFinishedArticleSelection(articleId) {
  const article = AppData.finished_articles.find(a => a.id === articleId);
  if (article) {
    article.selected = !article.selected;
    renderFinishedArticles();
  }
}

function toggleBeforeAfterComparison() {
  showComparison = !showComparison;
  const button = document.getElementById('toggleComparisonBtn');
  button.textContent = showComparison ? 'Hide Before/After' : 'Show Before/After';
  renderFinishedArticles();
}

function updateProcessingStats() {
  document.getElementById('totalProcessed').textContent = AppData.processing_stats.total_articles_processed;
  document.getElementById('avgProcessingTime').textContent = AppData.processing_stats.average_processing_time;
  document.getElementById('successRate').textContent = AppData.processing_stats.success_rate;
  document.getElementById('qualityImprovement').textContent = AppData.processing_stats.quality_improvement;
}

// Export Functions
function exportSelectedArticles() {
  const selectedArticles = AppData.finished_articles.filter(a => a.selected);
  const format = document.getElementById('exportFormat').value;
  
  if (selectedArticles.length === 0) {
    alert('Please select articles to export');
    return;
  }
  
  exportArticles(selectedArticles, format, 'selected');
}

function batchExportAll() {
  const format = document.getElementById('exportFormat').value;
  
  if (AppData.finished_articles.length === 0) {
    alert('No articles available for export');
    return;
  }
  
  exportArticles(AppData.finished_articles, format, 'all');
}

function exportSingleArticle(articleId, format) {
  const article = AppData.finished_articles.find(a => a.id === articleId);
  if (article) {
    exportArticles([article], format, 'single');
  }
}

function exportArticles(articles, format, scope) {
  let content = '';
  let filename = '';
  let mimeType = 'text/plain';
  
  const timestamp = new Date().toISOString().slice(0, 10);
  
  switch (format) {
    case 'txt':
      content = articles.map(article => 
        `${article.title}\n\n${article.content}\n\nQuality Scores:\n` +
        `- Readability: ${article.quality_scores.readability}\n` +
        `- SEO Score: ${article.quality_scores.seo_score}\n` +
        `- Human-likeness: ${article.quality_scores.human_likeness}\n` +
        `- Originality: ${article.quality_scores.originality}\n\n` +
        '---\n\n'
      ).join('');
      filename = `newsflow-export-${scope}-${timestamp}.txt`;
      mimeType = 'text/plain';
      break;
      
    case 'html':
      content = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>NewsFlow Export - ${scope}</title>
          <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
            .article { margin-bottom: 40px; border-bottom: 1px solid #eee; padding-bottom: 20px; }
            .title { color: #333; font-size: 24px; margin-bottom: 10px; }
            .content { line-height: 1.6; margin-bottom: 15px; }
            .scores { background: #f5f5f5; padding: 10px; border-radius: 5px; }
            .score { margin-right: 15px; }
          </style>
        </head>
        <body>
          <h1>NewsFlow Article Export</h1>
          ${articles.map(article => `
            <div class="article">
              <h2 class="title">${article.title}</h2>
              <div class="content">${article.content.replace(/\n/g, '<br>')}</div>
              <div class="scores">
                <span class="score">Readability: ${article.quality_scores.readability}</span>
                <span class="score">SEO: ${article.quality_scores.seo_score}</span>
                <span class="score">Human-likeness: ${article.quality_scores.human_likeness}</span>
                <span class="score">Originality: ${article.quality_scores.originality}</span>
              </div>
            </div>
          `).join('')}
        </body>
        </html>
      `;
      filename = `newsflow-export-${scope}-${timestamp}.html`;
      mimeType = 'text/html';
      break;
      
    case 'json':
      content = JSON.stringify({
        export_info: {
          timestamp: new Date().toISOString(),
          type: scope,
          total_articles: articles.length,
          exported_by: 'NewsFlow'
        },
        articles: articles
      }, null, 2);
      filename = `newsflow-export-${scope}-${timestamp}.json`;
      mimeType = 'application/json';
      break;
  }
  
  // Create and download file
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  alert(`Successfully exported ${articles.length} article(s) as ${format.toUpperCase()}`);
}

// Utility Functions
function formatDate(dateString) {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
}

// Global functions for onclick handlers
window.toggleArticleSelection = toggleArticleSelection;
window.selectArticle = selectArticle;
window.previewArticle = previewArticle;
window.toggleFinishedArticleSelection = toggleFinishedArticleSelection;
window.exportSingleArticle = exportSingleArticle;
window.switchSection = switchSection;